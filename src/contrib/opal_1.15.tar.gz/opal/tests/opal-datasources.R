#!/usr/bin/env Rscript

#
# Opal R client
#

library(opal)
# http login
#o<-opal.login('ruser', 'password', 'http://localhost:8080')
# https login with ssl options
o<-opal.login('ruser', 'password', 'https://localhost:8443',opts=list(ssl.verifyhost=0,ssl.verifypeer=0,sslversion=3))

message("**** datasources:")
opal.datasources(o)
message("**** opal-data datasource:")
opal.datasource(o,'opal-data')
message("**** opal-data datasource tables:")
opal.tables(o,'opal-data')
message("**** opal-data datasource HOP table:")
opal.table(o,'opal-data','HOP')
message("**** opal-data datasource HOP table GENDER variables:")
opal.variables(o,'opal-data','HOP')
message("**** opal-data datasource HOP table GENDER variable:")
opal.variable(o,'opal-data','HOP','GENDER')
message("**** missing variable:")
opal.variable(o,'opal-data','HOP','XXXX')

message("**** assign some variables:")
opal.assign(o,'SEX','opal-data.HOP:GENDER')
opal.assign(o,'BMI','opal-data.HOP:PM_BMI_CONTINUOUS')
opal.symbols(o)

message("**** execute some summary:")
opal.execute(o,'length(SEX)')
opal.execute(o,'summary(SEX)')
opal.execute(o,'summary(BMI)')

message("**** clean symbols:")
opal.rm(o,'SEX')
opal.rm(o,'BMI')
opal.symbols(o)

message("**** assign enumerated variables in a data.frame:")
opal.assign(o,'HOP','opal-data.HOP',variables=list('GENDER','PM_BMI_CONTINUOUS'))
opal.symbols(o)

message("**** execute some operations on the data.frame:")
opal.execute(o,'head(HOP)')
opal.execute(o,'colnames(HOP)')
opal.execute(o,'summary(HOP$GENDER)')
opal.execute(o,'summary(HOP$PM_BMI_CONTINUOUS)')

message("**** assign variables filtered by Magma javascript in a data.frame:")
opal.assign(o,'HOP','opal-data.HOP',variables='name().matches("DIAB")')

message("**** execute some operations on the data.frame:")
opal.execute(o,'head(HOP)')
vars <- opal.execute(o,'colnames(HOP)')
vars
lapply(vars, function(v) { opal.execute(o, paste0('summary(HOP$', v, ')'))  })

message("**** clean symbols and logout:")
opal.rm(o,'HOP')
opal.logout(o)