# Opal Admin

Opal R and Datashield administration toolbox.

## Opal R administration

* Install, remove packages
* Check package versions
* ...

## Opal Datashield administration

* Install Aggregate and Assign methods
* Install Datashield packages
* ...
