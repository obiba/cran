# dsBetaTestClient

[![Build Status](https://travis-ci.org/datashield/dsBetaTestClient.svg?branch=release)](https://travis-ci.org/datashield/dsBetaTestClient)
[![License](https://img.shields.io/badge/license-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0.html)

Beta versions of new DataSHIELD client functions
