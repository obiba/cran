opaladdons
==========

Meta-package for opal R client and R 3.x.
