dsGraphicsClient
================

DataSHIELD client site functions for graphics
