dsbaseclient
============

DataSHIELD base methods (client)