dsBaseClient
============

DataSHIELD client site base functions
