dsBaseClient
============

DataSHIELD client site base functions




| Branch | Test status |
| -------| ----------- |
| Master | [![Build Status](https://dev.azure.com/nob22/datashield/_apis/build/status/dsBaseClient?branchName=master)](https://dev.azure.com/nob22/datashield/_build/latest?definitionId=6&branchName=master) |

[![License](https://img.shields.io/badge/license-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0.html)

