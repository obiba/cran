# dsBetaTestClient

[![Build Status](https://dev.azure.com/nob22/dsBetaTest/_apis/build/status/datashield.dsBetaTestClient)](https://dev.azure.com/nob22/dsBetaTest/_build/latest?definitionId=1)
[![License](https://img.shields.io/badge/license-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0.html)

Beta versions of new DataSHIELD client functions
