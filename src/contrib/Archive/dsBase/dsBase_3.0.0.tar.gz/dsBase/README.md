dsBase
======

DataSHIELD server site base functions
