dsteststatsclient
=================

Datashield package for various statistical test (Client side)