#' Computes the product.
#'
#' @param a
#' @param b
#' @param c
#' @param d
#' @param e
#' @export
#' 
product <- function (a=1,b=1,c=1,d=1,e=1){
  a*b*c*d*e
}