#' Computes the sum.
#'
#' @param a
#' @param b
#' @param c
#' @param d
#' @param e
#' @export
#' 
sum <- function (a=0,b=0,c=0,d=0,e=0){
  a+b+c+d+e
}
