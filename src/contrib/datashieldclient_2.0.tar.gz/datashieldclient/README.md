datashieldclient
================

DataSHIELD meta-package (client side)