# Define the global variables 'offset.to.use', 'weights.to.use', 'out.table.real', 'out.table.dim' and 'out.table.dimnames'

utils::globalVariables(c('offset.to.use', 'weights.to.use', 'out.table.real', 'out.table.dim', 'out.table.dimnames'))
