## ----eval=FALSE----------------------------------------------------------
#  library(opal)
#  o <- opal.login('administrator', 'password', 'https://opal-demo.obiba.org')

## ----eval=FALSE----------------------------------------------------------
#  opal.file_download(o, '/tmp/datashield.zip')

## ----eval=FALSE----------------------------------------------------------
#  opal.file_download(o, '/tmp/datashield.zip', 'datashield-encrypted.zip', key='ABCDEFGHIJKL')

## ----eval=FALSE----------------------------------------------------------
#  list.files()
#  opal.file_upload(o, 'datashield.zip', '/projects/datashield')

## ----eval=FALSE----------------------------------------------------------
#  opal.file_mkdir(o, '/projects/datashield/foo')
#  opal.file_ls(o, '/projects/datashield')

## ----eval=FALSE----------------------------------------------------------
#  opal.file_mv(o, '/projects/datashield/datashield.zip', '/projects/datashield/foo')
#  opal.file_ls(o, '/projects/datashield/foo')

## ----eval=FALSE----------------------------------------------------------
#  opal.file_mv(o, '/projects/datashield/foo', '/projects/datashield/bar')
#  opal.file_ls(o, '/projects/datashield')

## ----eval=FALSE----------------------------------------------------------
#  opal.file_write(o, '/projects/datashield/bar/datashield.zip')
#  opal.execute(o, 'list.files()')

## ----eval=FALSE----------------------------------------------------------
#  opal.file_read(o, 'datashield.zip', '/projects/datashield/bar/ds.zip')
#  opal.file_ls(o, '/projects/datashield/bar')

## ----eval=FALSE----------------------------------------------------------
#  opal.file_rm(o, '/projects/datashield/bar')
#  opal.file_ls(o, '/projects/datashield')

## ----eval=FALSE----------------------------------------------------------
#  opal.logout(o)
#  unlink('datashield-encrypted.zip')
#  unlink('datashield.zip')

