dsbase
======

DataSHIELD base methods (server)