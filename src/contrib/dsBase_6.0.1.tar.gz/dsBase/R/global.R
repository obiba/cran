# Define the global variables 'offset.to.use', 'weights.to.use', 'out.table.real', 'out.table.dim', 'out.table.dimnames' and 'list.obj'

utils::globalVariables(c('offset.to.use', 'weights.to.use', 'out.table.real', 'out.table.dim', 'out.table.dimnames', 'list.obj'))
